package com.ifsc.listagem;

public class Planeta {
    String nome;
    Integer foto;

    public Planeta(String nome, Integer integer){
        this.nome = nome;
        this.foto = integer;
    }
}
