package com.ifsc.listagem;

public class Planeta {
    String nome;
    Integer integer;

    public Planeta(String nome, Integer integer){
        this.nome = nome;
        this.integer = integer;
    }
}
